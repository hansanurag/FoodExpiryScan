// -----------------------------
// Global State
// -----------------------------
let scannerRunning = false;
let currentImageMeta = null; // last uploaded image ka data

// -----------------------------
// THEME HANDLING (Dark <-> Light)
// -----------------------------
function applyTheme(theme) {
  const body = document.body;
  if (theme === "light") {
    body.classList.add("light-mode");
  } else {
    body.classList.remove("light-mode");
  }

  const themeBtn = document.getElementById("theme-toggle");
  if (themeBtn) {
    themeBtn.textContent =
      theme === "light" ? "Switch to Dark Mode" : "Switch to Light Mode";
  }
}

function toggleTheme() {
  const current = localStorage.getItem("theme") || "dark";
  const next = current === "dark" ? "light" : "dark";
  localStorage.setItem("theme", next);
  applyTheme(next);
}

// -----------------------------
// Logout (Settings se)
// -----------------------------
function logout() {
  localStorage.removeItem("token");
  window.location.href = "login.html";
}

/* -------------------------------
   Scanner Functions (Barcode)
--------------------------------*/
function showScannerContainer() {
  const container = document.getElementById("scanner-container");
  if (!container) return;
  container.innerHTML = "";
  container.style.display = "block";
}

function hideScannerContainer() {
  const container = document.getElementById("scanner-container");
  if (!container) return;

  const video = container.querySelector("video");
  if (video && video.srcObject) {
    const stream = video.srcObject;
    const tracks = stream.getTracks();
    tracks.forEach((t) => t.stop());
    video.srcObject = null;
  }

  container.style.display = "none";
  container.innerHTML = "";
}

function startScanner() {
  if (scannerRunning) return;
  showScannerContainer();

  if (typeof Quagga === "undefined") {
    console.error("QuaggaJS not loaded");
    alert("Barcode scanner library (QuaggaJS) not loaded.");
    return;
  }

  Quagga.init(
    {
      inputStream: {
        type: "LiveStream",
        target: document.querySelector("#scanner-container"),
        constraints: { facingMode: "environment" },
      },
      decoder: {
        readers: ["code_128_reader", "ean_reader", "ean_8_reader"],
      },
      locate: true,
    },
    (err) => {
      if (err) {
        console.error("Quagga init error:", err);
        hideScannerContainer();
        return;
      }
      Quagga.start();
      scannerRunning = true;
      const btn = document.getElementById("start-scan");
      if (btn) btn.innerText = "Stop Scanner";
    }
  );

  Quagga.onDetected((data) => {
    const code =
      data && data.codeResult && data.codeResult.code
        ? data.codeResult.code
        : null;
    if (!code) return;

    stopScanner();

    const nameInput = document.getElementById("item-name");
    const expInput = document.getElementById("item-expiry");

    if (nameInput) nameInput.value = code;

    const d = new Date();
    d.setDate(d.getDate() + 30);
    if (expInput) {
      expInput.value = d.toISOString().slice(0, 10);
    }

    const modal = document.getElementById("item-modal");
    if (modal) modal.classList.remove("hidden");
  });
}

function stopScanner() {
  if (scannerRunning && typeof Quagga !== "undefined") {
    Quagga.stop();
  }
  scannerRunning = false;
  const btn = document.getElementById("start-scan");
  if (btn) btn.innerText = "Start Scanner";
  hideScannerContainer();
}

/* -------------------------------
   Image Preview + Meta Data
--------------------------------*/
function previewImage(event) {
  const file = event.target.files && event.target.files[0];
  const preview = document.getElementById("preview");

  if (!preview) return;

  if (!file) {
    currentImageMeta = null;
    preview.src = "";
    preview.style.display = "none";
    return;
  }

  const imageURL = URL.createObjectURL(file);
  preview.src = imageURL;
  preview.style.display = "block";

  const reader = new FileReader();
  reader.onload = () => {
    currentImageMeta = {
      name: file.name,
      type: file.type,
      size: file.size,
      dataUrl: reader.result,
    };
  };
  reader.readAsDataURL(file);

  const result = document.getElementById("resultText");
  if (result) {
    result.innerText = "Image uploaded. Click 'Detect Expiry'.";
  }
}

/* -------------------------------
   Image Scan (Demo Expiry Detection)
--------------------------------*/
function sendImage() {
  const input = document.getElementById("imageInput");
  const result = document.getElementById("resultText");

  if (!input || !input.files || input.files.length === 0) {
    alert("Please upload an image first.");
    return;
  }

  const d = new Date();
  d.setDate(d.getDate() + 10);
  const expiryStr = d.toISOString().slice(0, 10);

  if (result) {
    result.innerText = `Detected expiry date (demo): ${expiryStr}`;
  }

  const nameInput = document.getElementById("item-name");
  const catInput = document.getElementById("item-category");
  const expInput = document.getElementById("item-expiry");

  if (nameInput && !nameInput.value) {
    nameInput.value = currentImageMeta?.name || "Scanned Image Item";
  }
  if (catInput) catInput.value = "Food";
  if (expInput) expInput.value = expiryStr;

  const modal = document.getElementById("item-modal");
  if (modal) modal.classList.remove("hidden");
}

/* -------------------------------
   Save Product with Backend + LocalStorage
--------------------------------*/
async function saveProductData(productData) {
  try {
    const token = localStorage.getItem("token");
    const res = await fetch("http://localhost:5000/api/inventory", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: JSON.stringify(productData),
    });

    if (!res.ok) {
      throw new Error("Backend not available");
    }

    await res.json();
  } catch (err) {
    console.error("Error saving to backend, using localStorage only:", err);
  }

  let items = JSON.parse(localStorage.getItem("scannedProducts")) || [];
  items.push(productData);
  localStorage.setItem("scannedProducts", JSON.stringify(items));
}

/* -------------------------------
   Inventory Rendering Helpers
--------------------------------*/
function getSavedItems() {
  return JSON.parse(localStorage.getItem("scannedProducts")) || [];
}

function loadInventory(filterText = "") {
  const tbody = document.getElementById("inventory-list");
  if (!tbody) return;

  tbody.innerHTML = "";

  const items = getSavedItems();
  const today = new Date();

  let safe = 0,
      soon = 0,
      expired = 0;

  const filter = filterText.toLowerCase();

  items.forEach((item, idx) => {
    const expDate = new Date(item.expiry);
    let status = "safe";

    if (expDate.toString() === "Invalid Date") {
      status = "safe";
    } else {
      if (expDate < today) status = "expired";
      else if ((expDate - today) / (1000 * 60 * 60 * 24) <= 7)
        status = "expiringsoon";
    }

    if (status === "safe") safe++;
    if (status === "expiringsoon") soon++;
    if (status === "expired") expired++;

    const combined = `${item.name || ""} ${item.category || ""} ${
      item.storage || ""
    } ${(item.quantity ?? "").toString()}`.toLowerCase();
    if (filter && !combined.includes(filter)) return;

    tbody.innerHTML += `
      <tr>
        <td>${item.name || "-"}</td>
        <td>${item.category || "-"}</td>
        <td>${item.quantity ?? "-"}</td>
        <td>${item.storage || "-"}</td>
        <td>${item.expiry || "-"}</td>
        <td><span class="status ${status}">${status}</span></td>
        <td><button class="delete-btn" onclick="deleteItem(${idx})">Delete</button></td>
      </tr>`;
  });

  const safeEl = document.getElementById("safe-count");
  const soonEl = document.getElementById("soon-count");
  const expEl = document.getElementById("expired-count");

  if (safeEl) safeEl.innerText = safe;
  if (soonEl) soonEl.innerText = soon;
  if (expEl) expEl.innerText = expired;
}

function deleteItem(idx) {
  let items = getSavedItems();
  items.splice(idx, 1);
  localStorage.setItem("scannedProducts", JSON.stringify(items));
  loadInventory();
}

/* -------------------------------
   Backup Data (Download JSON)
--------------------------------*/
function backupData() {
  const items = getSavedItems();

  if (!items || items.length === 0) {
    alert("No items to backup yet.");
    return;
  }

  const payload = {
    exportedAt: new Date().toISOString(),
    totalItems: items.length,
    items,
  };

  const json = JSON.stringify(payload, null, 2);
  const blob = new Blob([json], { type: "application/json" });
  const url = URL.createObjectURL(blob);

  const a = document.createElement("a");
  a.href = url;
  a.download = `foodexpiry-backup-${new Date()
    .toISOString()
    .slice(0, 10)}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);

  URL.revokeObjectURL(url);
  alert("✅ Backup downloaded successfully!");
}

/* -------------------------------
   DOM Events
--------------------------------*/
document.addEventListener("DOMContentLoaded", () => {
  // Theme init
  const savedTheme = localStorage.getItem("theme") || "dark";
  applyTheme(savedTheme);

  const themeBtn = document.getElementById("theme-toggle");
  if (themeBtn) {
    themeBtn.addEventListener("click", toggleTheme);
  }

  // Save Item
  const saveBtn = document.getElementById("save-item-btn");
  if (saveBtn) {
    saveBtn.addEventListener("click", async () => {
      const name = document.getElementById("item-name").value;
      const expiry = document.getElementById("item-expiry").value;
      const category = document.getElementById("item-category").value;
      const qty = parseInt(document.getElementById("item-qty").value, 10);
      const storage = document.getElementById("item-storage").value;

      if (!name || !expiry || !qty || qty <= 0) {
        alert("Please fill required fields correctly!");
        return;
      }

      const newItem = {
        name,
        expiry,
        category,
        quantity: qty,
        storage,
        time: new Date().toISOString(),
      };

      if (currentImageMeta) {
        newItem.image = {
          name: currentImageMeta.name,
          type: currentImageMeta.type,
          size: currentImageMeta.size,
          dataUrl: currentImageMeta.dataUrl,
        };
      }

      await saveProductData(newItem);

      const modal = document.getElementById("item-modal");
      if (modal) modal.classList.add("hidden");

      document.getElementById("item-name").value = "";
      document.getElementById("item-expiry").value = "";
      document.getElementById("item-category").value = "Food";
      document.getElementById("item-qty").value = 1;
      document.getElementById("item-storage").value = "Room";

      loadInventory();
    });
  }

  // Cancel modal
  const cancelBtn = document.getElementById("cancel-btn");
  if (cancelBtn) {
    cancelBtn.addEventListener("click", () => {
      const modal = document.getElementById("item-modal");
      if (modal) modal.classList.add("hidden");
    });
  }

  // Add item button
  const addBtn = document.getElementById("add-btn");
  if (addBtn) {
    addBtn.addEventListener("click", () => {
      const modal = document.getElementById("item-modal");
      if (modal) modal.classList.remove("hidden");
    });
  }

  // Barcode scanner button
  const startScanBtn = document.getElementById("start-scan");
  if (startScanBtn) {
    startScanBtn.addEventListener("click", () => {
      if (scannerRunning) stopScanner();
      else startScanner();
    });
  }

  // Search
  const searchInput = document.getElementById("search");
  if (searchInput) {
    searchInput.addEventListener("input", (e) => {
      loadInventory(e.target.value);
    });
  }

  // Sidebar navigation
  const sidebarItems = document.querySelectorAll(".sidebar ul li");
  sidebarItems.forEach((item) => {
    item.addEventListener("click", () => {
      sidebarItems.forEach((li) => li.classList.remove("active"));
      item.classList.add("active");

      const target = item.getAttribute("data-target");
      const section = document.getElementById(target);
      if (section) {
        section.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    });
  });

  // Backup button
  const backupBtn = document.getElementById("backup-btn");
  if (backupBtn) {
    backupBtn.addEventListener("click", backupData);
  }

  // Initial inventory load
  loadInventory();
});
