const mongoose = require("mongoose");

const itemSchema = new mongoose.Schema({
  name: String,
  category: String,
  quantity: Number,
  storage: String,
  expiry: Date,
  image: {
    name: String,
    type: String,
    size: Number,
    dataUrl: String
  },
  time: Date
});

module.exports = mongoose.model("Item", itemSchema);
