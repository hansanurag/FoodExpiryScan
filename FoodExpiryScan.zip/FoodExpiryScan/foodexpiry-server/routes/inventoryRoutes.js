const express = require("express");
const Item = require("../models/item");

const router = express.Router();

// ✅ Get all items
router.get("/inventory", async (req, res) => {
  const items = await Item.find();
  res.json(items);
});

// ✅ Add item
router.post("/inventory", async (req, res) => {
  const newItem = new Item(req.body);
  await newItem.save();
  res.json(newItem);
});

// ✅ Delete item
router.delete("/inventory/:id", async (req, res) => {
  await Item.findByIdAndDelete(req.params.id);
  res.json({ message: "Item deleted" });
});

module.exports = router;
